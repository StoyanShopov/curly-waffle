﻿namespace SBC.Common
{
    public static class GlobalConstants
    {
        public const string SystemName = "SBC";

        public const string AdministratorRoleName = "Administrator";
    }
}
